from Crypto.Cipher import DES
from Crypto import Random
import base64

def ByteToHex(msg):
    return ''.join( [ "%02X " % ord( x ) for x in msg ]).strip()

def HexToByte( msg ):
    bytes = []
    hexStr = ''.join( msg.split(" ") )
    for i in range(0, len(msg), 2):
        bytes.append( chr( int (msg[i:i+2], 16 ) ) )
    return ''.join( bytes )

try:
    cipher = DES.new("?????", DES.MODE_ECB) # someone needs a key
    file = open('decryptme', mode ='rb')
    bytes = file.read()
    print cipher.decrypt(bytes)
except:
    print "there is something seriously wrong with you"
